package tools;

import com.runemate.game.api.hybrid.GameEvents;
import com.runemate.game.api.script.framework.tree.LeafTask;
import com.runemate.game.api.script.framework.tree.TreeBot;
import com.runemate.game.api.script.framework.tree.TreeTask;

public class SampleApp extends TreeBot{
    @Override
    public void onStart(String... args) {
        setLoopDelay(100, 200);
        GameEvents.Universal.LOGIN_HANDLER.disable();
    }
    @Override
    public TreeTask createRootTask() {

        return new LeafTask(){
            @Override
            public void execute() {
            }
        };
    }

}
