package tools;

import com.runemate.game.api.client.embeddable.EmbeddableUI;
import com.runemate.game.api.hybrid.GameEvents;
import com.runemate.game.api.hybrid.util.Resources;
import com.runemate.game.api.script.framework.tree.LeafTask;
import com.runemate.game.api.script.framework.tree.TreeBot;
import com.runemate.game.api.script.framework.tree.TreeTask;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;

public class SimpleUI extends TreeBot implements  EmbeddableUI{
    private ObjectProperty<Node> botInterfaceProperty;
    private SimpleController controller;
    public int mode = 0;

    public SimpleUI(){
        setEmbeddableUI(this);
    }
    @Override
    public void onStart(String... args) {
        setLoopDelay(100, 200);
        GameEvents.Universal.LOGIN_HANDLER.disable();
    }
    @Override
    public TreeTask createRootTask() {

        return new LeafTask(){
            @Override
            public void execute() {
            }
        };
    }

    @Override
    public ObjectProperty<? extends Node> botInterfaceProperty() {
        if(botInterfaceProperty == null){
            FXMLLoader loader = new FXMLLoader();
            controller = new SimpleController(this);
            loader.setController(controller);
            try{
                Node node = loader.load(Resources.getAsStream("SimpleUI.fxml"));
                botInterfaceProperty = new SimpleObjectProperty<>(node);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return botInterfaceProperty;
    }
}
