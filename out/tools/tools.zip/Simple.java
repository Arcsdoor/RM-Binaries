package tools;

import com.runemate.game.api.hybrid.GameEvents;
import com.runemate.game.api.hybrid.entities.Player;
import com.runemate.game.api.hybrid.location.Area;
import com.runemate.game.api.hybrid.location.Coordinate;
import com.runemate.game.api.hybrid.region.Players;
import com.runemate.game.api.script.framework.LoopingBot;

public class Simple extends LoopingBot {
    @Override
    public void onStart(String... args) {
        setLoopDelay(100, 200);
        GameEvents.Universal.LOGIN_HANDLER.disable();
        GameEvents.Universal.GENIE_HANDLER.disable();
        GameEvents.OSRS.NPC_DISMISSER.disable();
    }

    Player myPlayer;

    @Override
    public void onLoop() {
        try {
            mainGo();
        } catch (NullPointerException npe) {

        }
    }

    void mainGo() {
        myPlayer = Players.getLocal();
    }

    Area myArea = new Area.Rectangular(new Coordinate(0, 0, 0), new Coordinate(0, 0, 0));
}
