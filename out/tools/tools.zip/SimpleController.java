package tools;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.util.ResourceBundle;

public class SimpleController extends GridPane implements Initializable {

    private final int numberOfModes = 3;
    private final SimpleUI bot;

    @FXML
    public Button mainButton;
    @FXML
    public Label modeLabel;
    @FXML
    public Label simpleInfo;

    //Rename to bot class
    public SimpleController(SimpleUI bot) {
        this.bot = bot;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setVisible(true);
        modeLabel.setText("Mode: " + bot.mode);
        mainButton.setOnAction((ActionEvent event) -> {
            bot.mode++;
            if(bot.mode >= numberOfModes){
                bot.mode = 0;
            }
            modeLabel.setText("Mode: " + bot.mode);
            simpleInfo.setText("Information: ");
        });
    }
}
