package extra.snippets;

public class Snippets{
    // Multi-threaded programming
    private Thread auxThread;
    private void runThread(){
        Runnable runnable = () -> {
            while(auxThread != null){
                try{
                    //Write Code
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        };
        if (auxThread == null) {
            auxThread = new Thread(runnable);
        }
        if (!auxThread.isAlive()) {
            auxThread.start();
        }
    }
}


