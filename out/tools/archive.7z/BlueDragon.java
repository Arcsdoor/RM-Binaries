package crafting;

import com.runemate.game.api.hybrid.Environment;
import com.runemate.game.api.hybrid.GameEvents;
import com.runemate.game.api.hybrid.entities.Player;
import com.runemate.game.api.hybrid.input.Keyboard;
import com.runemate.game.api.hybrid.local.hud.interfaces.*;
import com.runemate.game.api.hybrid.location.Area;
import com.runemate.game.api.hybrid.location.Coordinate;
import com.runemate.game.api.hybrid.region.GameObjects;
import com.runemate.game.api.hybrid.region.Players;
import com.runemate.game.api.hybrid.util.Timer;
import com.runemate.game.api.hybrid.util.calculations.Random;
import com.runemate.game.api.script.Execution;
import com.runemate.game.api.script.framework.tree.LeafTask;
import com.runemate.game.api.script.framework.tree.TreeBot;
import com.runemate.game.api.script.framework.tree.TreeTask;

public class BlueDragon extends TreeBot {
    @Override
    public void onStart(String... args) {
        setLoopDelay(100, 200);
        GameEvents.Universal.LOGIN_HANDLER.disable();
    }

    @Override
    public TreeTask createRootTask() {
        return new LeafTask() {
            Player myPlayer;
            Area myLocation = null;
            boolean mySetup = false;
            String item01 = "Blue dragon leather";
            String item02 = "Blue d'hide body";

            @Override
            public void execute() {
                if (mySetup) {
                    check();
                    if (Bank.isOpen()) {
                        if ((Inventory.contains(item02))) {
                            if (Inventory.containsAnyExcept("Thread", "Needle", item01, item02)) {
                                if (Bank.depositAllExcept("Thread", "Needle", item01)) {
                                    Execution.delayUntil(() -> !Inventory.contains(item01), 707, 909);
                                }
                            } else {
                                if (Bank.deposit(item02, 26)) {
                                    Execution.delayUntil(() -> !Inventory.contains(item01), 707, 909);
                                }
                            }
                        } else {
                            if (Inventory.getQuantity(item01) < 10) {
                                if (Bank.withdraw(item01, 26)) {
                                    Execution.delayUntil(() -> Inventory.contains(item01), 707, 909);
                                }
                            } else {
                                if (Bank.close()) {
                                    Execution.delayUntil(() -> !Bank.isOpen(), 707, 909);
                                }
                            }
                        }
                    } else {
                        if (Inventory.getQuantity(item01) > 5) {
                            if (Interfaces.newQuery().textContains("How many do you wish to make?").results().first() != null) {
                                Keyboard.pressKey(32);
                                Execution.delay(150, 340);
                                Keyboard.releaseKey(32);
                                Execution.delayUntil(() -> ChatDialog.getContinue() != null || Inventory.getQuantity(item01) <= 2, 30000, 40000);

                                if (!breakTimer.isRunning()) {
                                    Execution.delay(20000, 50000);
                                    breakTimer = new Timer(60000 * 15, 60000 * 25);
                                    breakTimer.reset();
                                    breakTimer.start();
                                    smallInterrupt = Random.nextInt(3, 7);
                                } else {
                                    if (Random.nextInt(1, 100) < smallInterrupt) {
                                        Execution.delay(1000, 7000);
                                    } else {
                                        if (Random.nextInt(1, 100) < 75) {
                                            Execution.delay(3000, 4000);
                                        }
                                    }
                                }

                            } else {
                                if (Inventory.getSelectedItem() != null && Inventory.getSelectedItem().getDefinition().getName().equals("Needle")) {
                                    setLeather();
                                    if (dragonLeather != null && dragonLeather.click()) {
                                        Execution.delayUntil(() -> Interfaces.newQuery().textContains("How many do you wish to make").results().first() != null, 4000, 7000);
                                    }
                                } else {
                                    if (Inventory.newQuery().names("Needle").results().first().click()) {
                                        Execution.delayUntil(() -> Inventory.getSelectedItem() != null, 707, 909);
                                    }
                                }
                            }
                        } else {
                            try {
                                if (GameObjects.newQuery().within(myLocation).actions(new String[]{"Bank", "Use"}).results().nearestTo(myPlayer).click()) {
                                    Execution.delayUntil(() -> Bank.isOpen(), 707, 909);
                                }
                            } catch (NullPointerException npe) {

                            }
                        }
                    }
                } else {
                    try {
                        setup();
                    } catch (NullPointerException npe) {
                        npe.printStackTrace();
                    }
                }

            }

            SpriteItem dragonLeather = null;

            public void setLeather() {
                try {
                    for (int i = 0; i < 28; i++) {
                        if (Inventory.getItemIn(i) != null && Inventory.getItemIn(i).getDefinition().getName().equals(item01)) {
                            dragonLeather = Inventory.getItemIn(i);
                            break;
                        }
                    }

                } catch (NullPointerException npe) {
                    npe.printStackTrace();
                }
            }

            Timer insuranceTimer;
            Timer breakTimer = new Timer(60000 * 15, 60000 * 25);
            int smallInterrupt = Random.nextInt(3, 7);

            public void setup() {
                myPlayer = Players.getLocal();

                if (myLocation == null) {
                    myLocation = new Area.Rectangular(new Coordinate(myPlayer.getPosition().getX() - 1, myPlayer.getPosition().getY() - 1, myPlayer.getPosition().getPlane()), new Coordinate(myPlayer.getPosition().getX() + 1, myPlayer.getPosition().getY() + 1, myPlayer.getPosition().getPlane()));
                    insuranceTimer = new Timer(3000, 5000);
                    insuranceTimer.reset();
                    insuranceTimer.start();
                    breakTimer.reset();
                    breakTimer.start();

                }

                if (item01 != null && item02 != null) {
                    mySetup = true;
                    System.out.println("Item01= " + item01);
                    System.out.println("Item02= " + item02);
                }

            }

            public void check() {

                if (Bank.isOpen()) {
                    if (Bank.getQuantity("Blue dragon leather") < 30) {
                        Execution.delay(1000);
                        if (Bank.getQuantity("Blue dragon leather") < 30) {
                            System.out.println("Low blue dragon leather");
                            Environment.getBot().pause();
                        }
                    }
                } else {
                    try {
                        if (insuranceTimer != null && !insuranceTimer.isRunning()) {
                            if (!myLocation.contains(myPlayer)) {
                                System.out.println("Player not in area");
                                Environment.getBot().pause();
                            }
                            if (!Inventory.contains("Thread")) {
                                System.out.println(Inventory.getItemIn(0).getDefinition().getName());
                                System.out.println("No Thread");
                                Environment.getBot().pause();
                            }
                            if (!Inventory.contains("Needle")) {
                                System.out.println(Inventory.getItemIn(1).getDefinition().getName());
                                System.out.println("No Needle");
                                Environment.getBot().pause();
                            }
                        }
                    } catch (NullPointerException npe) {
                        npe.printStackTrace();
                    }
                }
            }
        };
    }
}
