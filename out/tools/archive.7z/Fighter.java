package combat;

import com.runemate.game.api.hybrid.Environment;
import com.runemate.game.api.hybrid.local.hud.interfaces.*;

import com.runemate.game.api.client.embeddable.EmbeddableUI;
import com.runemate.game.api.hybrid.GameEvents;
import com.runemate.game.api.hybrid.entities.GroundItem;
import com.runemate.game.api.hybrid.entities.Npc;
import com.runemate.game.api.hybrid.entities.Player;
import com.runemate.game.api.hybrid.input.Keyboard;
import com.runemate.game.api.hybrid.location.Area;
import com.runemate.game.api.hybrid.location.Coordinate;
import com.runemate.game.api.hybrid.location.navigation.Traversal;
import com.runemate.game.api.hybrid.location.navigation.basic.BresenhamPath;
import com.runemate.game.api.hybrid.queries.GroundItemQueryBuilder;
import com.runemate.game.api.hybrid.queries.results.LocatableEntityQueryResults;
import com.runemate.game.api.hybrid.region.Npcs;
import com.runemate.game.api.hybrid.region.Players;
import com.runemate.game.api.hybrid.util.Resources;
import com.runemate.game.api.hybrid.util.Timer;
import com.runemate.game.api.hybrid.util.calculations.Distance;
import com.runemate.game.api.hybrid.util.calculations.Random;
import com.runemate.game.api.script.Execution;
import com.runemate.game.api.script.framework.tree.LeafTask;
import com.runemate.game.api.script.framework.tree.TreeBot;
import com.runemate.game.api.script.framework.tree.TreeTask;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import tools.Assist;

import java.util.regex.Pattern;

public class Fighter extends TreeBot implements EmbeddableUI {
    private ObjectProperty<Node> botInterfaceProperty;
    private FighterController controller;
    public int mode = 0;


    @Override
    public void onStart(String... args) {
        setLoopDelay(100, 200);
        GameEvents.Universal.LOGIN_HANDLER.disable();
    }

    @Override
    public TreeTask createRootTask() {
        return new LeafTask() {
            //Config
            boolean splashSpells = false;
            String itemToCollect = "Bones";
            int itemQuantity = 1;
            String targetName = "Seagull";
            String[] targetList;

            //Private data
            private Player myPlayer;
            private Area arenaArea = null;
            private String itemName;
            private long currentTime = System.currentTimeMillis();
            private int randomInt = 80;
            private int numberOfPlayers = 0;
            private Assist assist = new Assist();

            //Time settings for Splashing
            long startSplashResetTime = System.currentTimeMillis() * 1000 * 60 * (35 + (int) (Math.random() * 7));
            int splashInt = 1 + (int) (Math.random() * 4);

            Timer returnTimer = new Timer(100000000);

            private void arenaSetup() {
                myPlayer = Players.getLocal();
                assist.randomEventHandler(myPlayer);
                Area portArena = new Area.Rectangular(new Coordinate(3040, 3194, 0), new Coordinate(3018, 3210, 0));
                Area farmArena = new Area.Rectangular(new Coordinate(3021, 3297, 0), new Coordinate(3043, 3313, 0));
                Area ardyFarmArena = new Area.Rectangular(new Coordinate(2656, 3338, 0), new Coordinate(2675, 3358, 0));
                Area guildFarmArena = new Area.Rectangular(new Coordinate(2922, 3265, 0), new Coordinate(2938, 3280, 0));
                Area customArena = new Area.Rectangular(new Coordinate(myPlayer.getPosition().getX() - 14, myPlayer.getPosition().getY() - 14, 0), new Coordinate(myPlayer.getPosition().getX() + 14, myPlayer.getPosition().getY() + 14, myPlayer.getPosition().getPlane()));
                if (Equipment.contains(Pattern.compile("kiteshield")) || Equipment.contains("Skull sceptre (i)") || Equipment.contains("Gnome amulet") || Equipment.contains("Granite legs")) {
                    splashSpells = true;
                    print("Spash Mode On");
                    if (Inventory.contains(Pattern.compile("rune")) && Inventory.getQuantity(Pattern.compile("rune")) < 500) {
                        Environment.getBot().stop("No Runes");
                    }
                }
                if (arenaArea == null) {
                    if (portArena.contains(myPlayer)) {
                        arenaArea = portArena;
                        targetName = "Seagull";
                        targetList = new String[1];
                        targetList[0] = "Seagull";
                    } else {
                        if (farmArena.contains(myPlayer)) {
                            arenaArea = farmArena;
                            targetName = "Cow";
                            targetList = new String[2];
                            targetList[0] = "Cow";
                            targetList[1] = "Cow calf";
                        } else {
                            if (ardyFarmArena.contains(myPlayer)) {
                                arenaArea = ardyFarmArena;
                                targetName = "Cow";
                                targetList = new String[2];
                                targetList[0] = "Cow";
                                targetList[1] = "Cow calf";
                            } else {
                                if (guildFarmArena.contains(myPlayer)) {
                                    arenaArea = guildFarmArena;
                                    targetName = "Cow";
                                    targetList = new String[2];
                                    targetList[0] = "Cow";
                                    targetList[1] = "Cow calf";
                                } else {
                                    if (customArena.contains(myPlayer)) {
                                        arenaArea = customArena;
                                        targetName = "Seagull";
                                        targetList = new String[3];
                                        targetList[0] = "Seagull";
                                        targetList[1] = "Icefiend";
                                        targetList[2] = "Lesser demon";
                                    }
                                }
                            }
                        }
                    }
                }
            }

            private Npc fightingTarget;
            private Npc newTarget;
            private Thread auxThread = null;

            private void runFighterThread() {
                Runnable runnable = () -> {
                    while (auxThread != null) {
                        try {
                            fightingTarget = getFightingTarget();
                            numberOfPlayers = Players.newQuery().results().asList().size();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                };
                if (auxThread == null) {
                    auxThread = new Thread(runnable);
                }
                if (!auxThread.isAlive()) {
                    auxThread.start();
                }
            }

            public Npc getFightingTarget() {
                Npc target = null;
                Player player = Players.getLocal();
                LocatableEntityQueryResults enemies;
                if (targetList != null) {
                    enemies = Npcs.newQuery().within(arenaArea).names(targetList).results();
                } else {
                    enemies = Npcs.newQuery().within(arenaArea).names(targetName).results();
                }
                for (int i = 0; i < enemies.asList().size(); i++) {
                    Npc enemy = (Npc) enemies.get(i);
                    if (enemy.getTarget() != null) {
                        if (enemy.getTarget().getName().equals(player.getName())) {
                            target = enemy;
                            if (target.getHealthGauge() != null && target.getHealthGauge().getPercent() == 0) {
                                target = null;
                            }
                            break;
                        }
                    }
                }
                return target;
            }

            private Npc getNewTarget() {
                Npc target = null;
                LocatableEntityQueryResults enemies;
                if (targetList != null) {
                    enemies = Npcs.newQuery().within(arenaArea).names(targetList).results();
                } else {
                    enemies = Npcs.newQuery().within(arenaArea).names(targetName).results();
                }
                double distance = 100;

                for (int i = 0; i < enemies.asList().size(); i++) {
                    Npc enemy = (Npc) enemies.get(i);
                    if (enemy.getTarget() == null && enemy.getHealthGauge() == null) {
                        if (distance > enemy.distanceTo(myPlayer)) {
                            target = enemy;
                            distance = target.distanceTo(myPlayer);
                        }
                    }
                }
                return target;
            }

            int runNumber = 15;

            @Override
            public void execute() {
                arenaSetup();
                runFighterThread();
                if (Traversal.getRunEnergy() >= 50 + runNumber && !Traversal.isRunEnabled() && !Bank.isOpen()) {
                    Traversal.toggleRun();
                    runNumber = Random.nextInt(15, 35);
                    Execution.delay(707, 909);
                }
                if (mode == 1) {
                    itemName = itemToCollect;
                    itemQuantity = 1;
                } else {
                    if (mode == 2) {
                        itemQuantity = 4;
                        if (Equipment.contains("Iron arrow")) {
                            itemName = "Iron arrow";
                        } else {
                            if (Equipment.contains("Bone bolts")) {
                                itemName = "Bone bolts";
                            }
                        }
                    } else {
                        itemName = "";
                    }

                }
                GroundItem groundItem = null;
                try {
                    groundItem = new GroundItemQueryBuilder().within(arenaArea).names(itemName).quantity(itemQuantity).results().nearest();
                } catch (Exception e) {
                    System.out.println("Ground item error");
                }

                if (currentTime + 300000 < System.currentTimeMillis()) {
                    currentTime = System.currentTimeMillis();
                    randomInt = (int) (Math.random() * 100);
                }
                if (startSplashResetTime < System.currentTimeMillis()) {
                    startSplashResetTime = System.currentTimeMillis() * 1000 * 60 * 35 + (int) (Math.random() * 7);
                    splashInt = 1 + (int) (Math.random() * 3);
                }
                if (ChatDialog.isOpen()) {
                    try {
                        if (myPlayer.getHealthGauge() == null) {
                            if (splashInt == 2) {
                                //Why is this if statement here?
                                ChatDialog.getContinue().select();
                            } else {
                                // 32 = Space
                                Keyboard.pressKey(32);
                                Execution.delay(100, 200);
                                Keyboard.releaseKey(32);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    Execution.delay(777);
                }

                try {
                    returnToBattle();
                    if (groundItem != null && groundItem.getQuantity() < itemQuantity) {
                        groundItem = null;
                    }

                    if (arenaArea.contains(myPlayer) && (groundItem == null || numberOfPlayers > 1)) {
                        if (!Inventory.contains("Bones")) {
                            //If fightingTarget is null, player is not in combat.
                            if (fightingTarget == null) {
                                newTarget = getNewTarget();
                                //Both targets must be null to avoid stall
                                if (newTarget != null && newTarget.getTarget() == null && myPlayer.getTarget() == null && newTarget.getHealthGauge() == null) {
                                    if (randomInt > 80) {
                                        Execution.delay(700, 1800);
                                    }
                                    if (!newTarget.isVisible()) {
                                        BresenhamPath.buildTo(newTarget).step();
                                        Execution.delayUntil(() -> newTarget.isVisible(), 707, 1500);
                                    }

                                    if (newTarget.interact("Attack")) {
                                        print("Activating combat mode");
                                        Execution.delayUntil(() -> newTarget.getHealthGauge() != null, 1400, 2550);
                                    }

                                }
                            } else {
                                if ((fightingTarget != null && fightingTarget.getHealthGauge() == null) || (fightingTarget.getTarget() == null && fightingTarget.getHealthGauge() == null) || ChatDialog.isOpen()) {

                                    if (fightingTarget.interact("Attack")) {
                                        print("Power flows within you");
                                        if (splashSpells == true) {
                                            if (fightingTarget.getDefinition().getName().equals("Lesser demon")) {
                                                print("Fighting lesser demon");
                                                Execution.delayUntil(() -> assist.randomEventHandler(myPlayer), 45000 * splashInt, 70000 * splashInt);
                                            } else {
                                                Execution.delayUntil(() -> assist.randomEventHandler(myPlayer), 120000 * splashInt, 240000 * splashInt);
                                            }
                                        } else {
                                            Execution.delayUntil(() -> fightingTarget.getHealthGauge() != null, 2400, 3550);
                                        }
                                    }


                                }
                            }
                        } else {
                            SpriteItem bones = Inventory.newQuery().names("Bones").results().first();
                            if (bones != null && fightingTarget == null && myPlayer.getTarget() == null && !Inventory.isFull() & bones.isVisible()) {
                                int tempNumOfInvSpace = Inventory.getEmptySlots();
                                if (bones.interact("Bury")) {
                                    Execution.delayUntil(() -> Inventory.getEmptySlots() == tempNumOfInvSpace + 1, 800, 900);
                                }

                            }
                        }
                    } else {
                        if (fightingTarget == null && myPlayer.getTarget() == null && numberOfPlayers == 1) {
                            if (randomInt > 95) {
                                Execution.delay(200, 300);
                            }
                            int tempNumOfInvSpace = Inventory.getEmptySlots();
                            if (mode == 1 && groundItem.interact("Take")) {
                                Execution.delayUntil(() -> Inventory.getEmptySlots() == tempNumOfInvSpace - 1, 2200, 2950);
                            } else {
                                if (mode == 2 && groundItem.getQuantity() >= 4 && groundItem.interact("Take")) {
                                    Execution.delayUntil(() -> Inventory.getEmptySlots() == tempNumOfInvSpace - 1, 2200, 2950);
                                }
                            }

                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            private void returnToBattle() {
                if (!arenaArea.contains(myPlayer) && Distance.between(arenaArea, myPlayer) < 50) {
                    if (!returnTimer.isRunning()) {
                        returnTimer.reset();
                        returnTimer.start();
                    } else {
                        if (returnTimer.getElapsedTime() > 7000) {
                            Npc randomCow = Npcs.newQuery().within(arenaArea).names(targetList).results().random();
                            if (Random.nextInt(100) > 88 && BresenhamPath.buildTo(randomCow.getPosition()).step()) {
                                Execution.delay(2222, 5555);
                                returnTimer.stop();
                            } else {
                                if (randomCow.click()) {
                                    Execution.delay(2222, 5555);
                                    returnTimer.stop();
                                }
                            }
                        }
                    }
                }
            }
        };
    }


    private void print(String x) {
        System.out.println(x);
    }

    public Fighter() {
        setEmbeddableUI(this);
    }

    @Override
    public ObjectProperty<? extends Node> botInterfaceProperty() {
        if (botInterfaceProperty == null) {
            FXMLLoader loader = new FXMLLoader();
            controller = new FighterController(this);
            loader.setController(controller);
            try {
                Node node = loader.load(Resources.getAsStream("tools/SimpleUI.fxml"));
                botInterfaceProperty = new SimpleObjectProperty<>(node);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return botInterfaceProperty;
    }
}
