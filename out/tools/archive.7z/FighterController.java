package combat;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.util.ResourceBundle;

public class FighterController extends GridPane implements Initializable {

    private final int numberOfModes = 3;
    private final Fighter bot;

    @FXML
    public Button mainButton;
    @FXML
    public Label modeLabel;
    @FXML
    public Label simpleInfo;

    public FighterController(Fighter bot) {
        this.bot = bot;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setVisible(true);
        modeLabel.setText("Mode: " + bot.mode);
        simpleInfo.setText("We fighting, boys\nMode 0 = Fight only \nMode 1 = Fight and collect \nMode 2 = Autism");
        mainButton.setOnAction((ActionEvent event) -> {
            bot.mode++;
            if(bot.mode >= numberOfModes){
                bot.mode = 0;
            }
            modeLabel.setText("Mode: " + bot.mode);

        });
    }
}
