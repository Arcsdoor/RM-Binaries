package thief;

import com.runemate.game.api.hybrid.Environment;
import com.runemate.game.api.hybrid.GameEvents;
import com.runemate.game.api.hybrid.RuneScape;
import com.runemate.game.api.hybrid.entities.GameObject;
import com.runemate.game.api.hybrid.entities.Npc;
import com.runemate.game.api.hybrid.entities.Player;
import com.runemate.game.api.hybrid.input.Mouse;
import com.runemate.game.api.hybrid.local.Camera;
import com.runemate.game.api.hybrid.local.Skill;
import com.runemate.game.api.hybrid.local.hud.Menu;
import com.runemate.game.api.hybrid.local.hud.interfaces.*;
import com.runemate.game.api.hybrid.location.Area;
import com.runemate.game.api.hybrid.location.Coordinate;
import com.runemate.game.api.hybrid.location.navigation.basic.BresenhamPath;
import com.runemate.game.api.hybrid.location.navigation.basic.ViewportPath;
import com.runemate.game.api.hybrid.location.navigation.cognizant.RegionPath;
import com.runemate.game.api.hybrid.region.GameObjects;
import com.runemate.game.api.hybrid.region.Npcs;
import com.runemate.game.api.hybrid.region.Players;
import com.runemate.game.api.hybrid.util.calculations.Distance;
import com.runemate.game.api.script.Execution;
import com.runemate.game.api.script.framework.tree.LeafTask;
import com.runemate.game.api.script.framework.tree.TreeBot;
import com.runemate.game.api.script.framework.tree.TreeTask;
import tools.Assist;

public class OldKnight extends TreeBot {
    @Override
    public void onStart(String... args) {
        setLoopDelay(100, 200);
        GameEvents.Universal.LOGIN_HANDLER.disable();
    }

    @Override
    public TreeTask createRootTask() {
        return new LeafTask() {
            long ctime = System.currentTimeMillis();
            long stime = System.currentTimeMillis();
            long ntime = stime;
            long sxp = Skill.THIEVING.getExperience();

            Area Spot = new Area.Rectangular(new Coordinate(2670, 3316, 0), new Coordinate(2672, 3318, 0));
            Area Lock = new Area.Rectangular(new Coordinate(2671, 3315, 0), new Coordinate(2672, 3315, 0));

            Npc knight = Npcs.newQuery().within(Lock).names("Knight of Ardougne").results().first();
            Player player;
            Assist myAssist = new Assist();
            int pouchQuantity;
            int foodQuantity;
            int rando = 14;
            int pouchLimit = 20;

            //Important
            boolean readyToSteal = false;
            int foodMin = 1;
            boolean useDodgy = false;
            boolean mustEat = true;

            @Override
            public void execute() {
                //OPTIONS

                String foodName = "Cake";
                boolean pauseAtBank = false;

                if (Skill.THIEVING.getBaseLevel() >= 99 && foodMin != -1) {
                    foodMin = -1;
                    useDodgy = false;
                    mustEat = false;
                }
                //Quit timer
                boolean timeLimit = true;

                player = Players.getLocal();
                knight = Npcs.newQuery().within(Lock).names("Knight of Ardougne").results().first();

                if (myAssist.randomEventHandler(player)) {
                    return;
                }

                SpriteItem Food = Inventory.newQuery().actions("Eat").results().first();
                SpriteItem Pouch = Inventory.newQuery().actions("Open-all").results().first();
                SpriteItem dodgyNecklace = Inventory.newQuery().actions("Wear").results().first();
                pouchQuantity = 0;
                foodQuantity = 0;
                try {
                    if (Pouch != null) {
                        pouchQuantity = Pouch.getQuantity();
                    }
                    if (Food != null) {
                        foodQuantity = Inventory.newQuery().actions("Eat").results().size();
                    }
                } catch (NullPointerException npe) {
                    npe.printStackTrace();
                }


                if (System.currentTimeMillis() > ctime + 100000 && mustEat) {
                    rando = (int) (Math.random() * 6) + 9;
                    ctime = System.currentTimeMillis();
                    System.out.println("Heal at: " + rando);
                }

                if (System.currentTimeMillis() > ntime + 60000) {
                    pouchLimit = (int) (Math.random() * 10) + 12;
                    ntime = System.currentTimeMillis();
                    double timePassed = (double) (ntime - stime) / 1000 / 3600;
                    System.out.println("Time: " + timePassed + " Hours\nXP/HOUR: " + ((Skill.THIEVING.getExperience() - sxp)) / timePassed);
                    print("Current Level: " + Skill.THIEVING.getBaseLevel());
                    if (timePassed >= 5.5 && timeLimit) {
                        if (Health.getCurrent() >= 12) {
                            RuneScape.logout();
                            Execution.delay(250);
                            Environment.getBot().stop("Time Limit");
                        }
                    }

                }
                if (foodQuantity <= foodMin && mustEat) {
                    //Alarm
                    for (int i = 0; i < 3; i++) {
                        if (readyToSteal) {
                            java.awt.Toolkit.getDefaultToolkit().beep();
                            Execution.delay(500);
                        }
                    }
                    if (pouchQuantity != 0) {
                        try {
                            if(Execution.delay(200,300) && Pouch.interact("Open-all")){
                                Execution.delayUntil(()-> Inventory.newQuery().actions("Open-all").results().first() == null,1007, 1209);
                            }
                        } catch (NullPointerException npe) {
                            npe.printStackTrace();
                        }
                        return;
                    } else {
                        readyToSteal = false;
                    }
                }
                if (readyToSteal) {
                    if (knight == null || !Lock.contains(knight)) {
                        Npc knight = Npcs.newQuery().within(Lock).names("Knight of Ardougne").results().first();

                        if (knight == null) {
                            WorldHop.hopToRandom(true);
                            Execution.delay(6200, 7500);
                            return;
                        }
                    }

                    try {
                        if (Camera.getYaw() < 75) {
                            Camera.turnTo(130 + (int) ((Math.random() * 11)));
                            Execution.delay(505, 707);
                            return;
                        }

                        if (Pouch.getQuantity() >= pouchLimit) {
                            if(Execution.delay(200,300) && Pouch.interact("Open-all")){
                                Execution.delayUntil(()-> Inventory.newQuery().actions("Open-all").results().first() == null,1007, 1209);
                            }
                            return;
                        }

                        if (useDodgy && dodgyNecklace != null) {
                            if (Equipment.getItemIn(2) == null) {
                                Execution.delay(707, 909);
                                dodgyNecklace.interact("Wear");
                                Execution.delay(707, 909);
                                return;
                            }
                        }
                    } catch (NullPointerException npe) {
                    }

                    if (Spot.contains(player)) {
                        if (Health.getCurrent() > rando && knight != null) {
                            try {
                                if (Lock.contains(knight) && pouchQuantity < 28) {
                                    if (Menu.contains("Pickpocket")) {
                                        if (Mouse.click(Mouse.Button.LEFT)) {
                                            Execution.delay(300, 500);
                                        }
                                    } else {
                                        if (knight.click()) {
                                            Execution.delay(300, 500);
                                        }
                                    }
                                } else {
                                    knight = null;
                                }
                            } catch (NullPointerException e) {
                                System.out.println("NPE: Trying to pickpocket Knight");
                                knight = null;
                            }
                        } else {
                            if (mustEat) {
                                if (Food.interact("Eat")) {
                                    Execution.delay(507, 805);
                                    if (Health.getCurrent() <= 12) {
                                        Execution.delay(507, 805);
                                    }
                                }
                            }
                        }
                    } else {
                        readyToSteal = false;
                        RegionPath Spotfix;
                        Spotfix = RegionPath.buildTo(new Coordinate(2671, 3316, 0));

                        try {
                            if (knight != null && System.currentTimeMillis() % 2 == 0) {
                                Spotfix = RegionPath.buildTo(new Coordinate(knight.getPosition().getX(), knight.getPosition().getY() + 1, 0));
                            }
                        } catch (NullPointerException e) {
                            System.out.println("NPE: Trying to fix location ");
                            knight = null;
                        }
                        if (Spotfix != null && System.currentTimeMillis() % 2 == 0) {
                            ViewportPath.convert(Spotfix).getNext().click();
                            Execution.delay(707, 1205);
                        } else {
                            if (Spotfix != null) {
                                Spotfix.step();
                            }
                        }
                    }
                } else {
                    int dodgyAmount = 7;

                    Area runningToBank = new Area.Rectangular(new Coordinate(2678, 3310, 0), new Coordinate(2609, 3345, 0));
                    Area outsideHouse = new Area.Rectangular(new Coordinate(2669, 3313, 0), new Coordinate(2666, 3316, 0));
                    Area insideHouse01 = new Area.Rectangular(new Coordinate(2672, 3315, 0), new Coordinate(2670, 3319, 0));
                    Area insideHouse02 = new Area.Rectangular(new Coordinate(2672, 3317, 0), new Coordinate(2668, 3319, 0));
                    Area insideBank = new Area.Rectangular(new Coordinate(2620, 3332, 0), new Coordinate(2615, 3334, 0));
                    Coordinate midPath = new Coordinate(2653, 3332, 0);

                    BresenhamPath midJog = BresenhamPath.buildTo(midPath);
                    BresenhamPath bankJog = BresenhamPath.buildTo(insideBank.getCenter());
                    BresenhamPath outsideHouseJog = BresenhamPath.buildTo(outsideHouse.getCenter());
                    BresenhamPath insideHouseJog = BresenhamPath.buildTo(insideHouse01.getCenter());

                    GameObject closedDoor = GameObjects.newQuery().within(outsideHouse).actions("Open").results().first();
                    GameObject openDoor = GameObjects.newQuery().within(insideHouse01).actions("Close").results().first();

                    if (insideHouse01.contains(player) || insideHouse02.contains(player)) {
                        if (foodQuantity > foodMin && (Inventory.getEmptySlots() >= 1 || pouchQuantity > 0)) {
                            readyToSteal = true;
                        } else {
                            if (Equipment.getItemIn(2) == null && foodQuantity <= foodMin) {
                                if (openDoor != null) {
                                    //run outside house
                                    try {
                                        midJog.step();
                                        Execution.delay(707, 909);
                                    } catch (NullPointerException npe) {
                                        npe.printStackTrace();
                                    }
                                } else {
                                    // open the door
                                    try {
                                        closedDoor.interact("Open");
                                        Execution.delayUntil(() -> GameObjects.newQuery().within(outsideHouse).actions("Open").results().first() == null, 707, 2100);
                                    } catch (NullPointerException npe) {
                                    }
                                }
                            } else {
                                //remove necklace
                                try {
                                    Equipment.getItemIn(2).interact("Remove");
                                    Execution.delayUntil(() -> Equipment.getItemIn(2) == null, 505, 909);
                                } catch (NullPointerException npe) {
                                }
                            }
                        }
                    } else {
                        if (outsideHouse.contains(player)) {
                            if (useDodgy && Equipment.getItemIn(2) == null && Inventory.contains("Dodgy necklace") && foodQuantity > foodMin && Inventory.contains("Coins") && Inventory.getEmptySlots() == 0 && !Bank.isOpen()) {
                                dodgyNecklace.interact("Wear");
                                Execution.delay(707, 909);
                            }
                            if (foodQuantity > foodMin) {
                                if (openDoor != null) {
                                    //run inside house
                                    try {
                                        insideHouseJog.step();
                                        Execution.delay(707, 909);
                                    } catch (NullPointerException npe) {
                                        npe.printStackTrace();
                                    }
                                } else {
                                    //open the door
                                    try {
                                        closedDoor.interact("Open");
                                        Execution.delayUntil(() -> GameObjects.newQuery().within(outsideHouse).actions("Open").results().first() == null, 707, 2100);
                                    } catch (NullPointerException npe) {
                                    }
                                }
                            } else {
                                //run to bank
                                try {
                                    midJog.step();
                                    Execution.delay(707, 909);
                                } catch (NullPointerException npe) {
                                    npe.printStackTrace();
                                }
                            }
                        } else {
                            if (insideBank.contains(player)) {
                                if ((Equipment.getItemIn(2) != null && Inventory.contains("Dodgy necklace") && foodQuantity > foodMin && Inventory.contains("Coins") && Inventory.getEmptySlots() >= 1) || foodQuantity > foodMin && Inventory.contains("Coins") && Inventory.getEmptySlots() >= 1 && !useDodgy) {
                                    //run to outside house
                                    try {
                                        midJog.step();
                                        Execution.delay(707, 909);
                                    } catch (NullPointerException npe) {
                                        npe.printStackTrace();
                                    }
                                } else {
                                    if (useDodgy && Equipment.getItemIn(2) == null && Inventory.contains("Dodgy necklace") && foodQuantity > foodMin && Inventory.contains("Coins") && Inventory.getEmptySlots() == 0 && !Bank.isOpen()) {
                                        dodgyNecklace.interact("Wear");
                                        Execution.delay(707, 909);
                                    } else {
                                        if (Bank.isOpen()) {
                                            if (pauseAtBank || Inventory.contains("Lamp")) {
                                                Environment.getBot().pause();
                                            }
                                            if (foodQuantity > foodMin) {
                                                Bank.close();
                                                Execution.delay(707, 909);
                                            } else {
                                                if (Inventory.getEmptySlots() != 28) {
                                                    Bank.depositInventory();
                                                    Execution.delay(707, 909);
                                                } else {
                                                    while (Bank.isOpen() && Inventory.getEmptySlots() != 1) {
                                                        if (Inventory.contains("Dodgy necklace") || !useDodgy) {
                                                            if (Inventory.isFull() && !useDodgy) {
                                                                Bank.depositInventory();
                                                            } else {
                                                                if (Inventory.contains("Coins")) {
                                                                    Bank.withdraw(foodName, 26);
                                                                } else {
                                                                    Bank.withdraw("Coins", 1);
                                                                }
                                                            }
                                                        } else {
                                                            if (useDodgy) {
                                                                Bank.withdraw("Dodgy necklace", dodgyAmount);
                                                            }
                                                        }
                                                        Execution.delay(808, 1101);
                                                    }
                                                }
                                            }
                                        } else {
                                            Bank.open();
                                        }
                                    }
                                }
                            } else {
                                if (runningToBank.contains(player)) {
                                    if (Equipment.getItemIn(2) == null && Inventory.contains("Dodgy necklace") && foodQuantity > foodMin && Inventory.contains("Coins") && Inventory.getEmptySlots() == 0 && !Bank.isOpen()) {
                                        dodgyNecklace.interact("Wear");
                                        Execution.delay(707, 909);
                                    }
                                    if (foodQuantity <= foodMin) {
                                        if (Distance.between(player, midPath) > 18 && player.getPosition().getX() > midPath.getX()) {
                                            try {
                                                midJog.step();
                                                Execution.delay(707, 909);
                                            } catch (NullPointerException npe) {
                                                npe.printStackTrace();
                                            }
                                        } else {
                                            try {
                                                bankJog.step();
                                                Execution.delay(707, 909);
                                            } catch (NullPointerException npe) {
                                                npe.printStackTrace();
                                            }
                                        }
                                    } else {
                                        if (Distance.between(player, midPath) > 18 && player.getPosition().getX() < midPath.getX()) {
                                            try {
                                                midJog.step();
                                                Execution.delay(707, 909);
                                            } catch (NullPointerException npe) {
                                                npe.printStackTrace();
                                            }
                                        } else {
                                            try {
                                                if (openDoor != null) {
                                                    insideHouseJog.step();
                                                } else {
                                                    outsideHouseJog.step();
                                                }
                                                Execution.delay(707, 909);
                                            } catch (NullPointerException npe) {
                                                npe.printStackTrace();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            public void print(String x) {
                System.out.println(x);
            }
        };
    }
}
