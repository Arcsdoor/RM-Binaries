package thief.master;

import com.runemate.game.api.client.embeddable.EmbeddableUI;
import com.runemate.game.api.hybrid.Environment;
import com.runemate.game.api.hybrid.GameEvents;
import com.runemate.game.api.hybrid.RuneScape;
import com.runemate.game.api.hybrid.entities.Npc;
import com.runemate.game.api.hybrid.entities.Player;
import com.runemate.game.api.hybrid.input.Keyboard;
import com.runemate.game.api.hybrid.input.Mouse;
import com.runemate.game.api.hybrid.local.Camera;
import com.runemate.game.api.hybrid.local.Worlds;
import com.runemate.game.api.hybrid.local.hud.Menu;
import com.runemate.game.api.hybrid.local.hud.interfaces.*;
import com.runemate.game.api.hybrid.location.Area;
import com.runemate.game.api.hybrid.location.Coordinate;
import com.runemate.game.api.hybrid.location.navigation.basic.BresenhamPath;
import com.runemate.game.api.hybrid.region.Npcs;
import com.runemate.game.api.hybrid.region.Players;
import com.runemate.game.api.hybrid.util.Resources;
import com.runemate.game.api.hybrid.util.Timer;
import com.runemate.game.api.hybrid.util.calculations.Random;
import com.runemate.game.api.osrs.local.hud.interfaces.ControlPanelTab;
import com.runemate.game.api.script.Execution;
import com.runemate.game.api.script.framework.tree.LeafTask;
import com.runemate.game.api.script.framework.tree.TreeBot;
import com.runemate.game.api.script.framework.tree.TreeTask;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;

import java.util.ArrayList;
import java.util.Arrays;


public class Master extends TreeBot implements  EmbeddableUI{
    private ObjectProperty<Node> botInterfaceProperty;
    private MasterController controller;
    public int mode = 0;

    public Master(){
        setEmbeddableUI(this);
    }
    @Override
    public void onStart(String... args) {
        setLoopDelay(100, 200);
        GameEvents.Universal.LOGIN_HANDLER.disable();
    }
    @Override
    public TreeTask createRootTask() {
        return new LeafTask(){
            Area houseArea = new Area.Rectangular(new Coordinate(1782,3590,0), new Coordinate(1788,3594,0));
            Area houseUpArea = new Area.Rectangular(new Coordinate(1782,3590,1), new Coordinate(1788,3594,1));
            Area wideArea = new Area.Rectangular(new Coordinate(1774,3686,0), new Coordinate(1792,3663,0));
            Area waitArea =  new Area.Rectangular(new Coordinate(1781,3677,0), new Coordinate(1782,3672,0));
            Area dangerArea = new Area.Rectangular(new Coordinate(1772,3676,0), new Coordinate(1779,3673,0));

            final String[] specialSeedsArr = {"Ranarr seed", "Torstol seed", "Snapdragon seed", "Toadflax seed", "Avantoe seed", "Kwuarm seed"};
            boolean dropSeeds = false;
            SpriteItem seedBoxSprite;

            Npc farmerNPC;
            Coordinate farmerPos = null;
            boolean standingStill = false;
            boolean fastPickpocket = true;
            int cameraFix = 0;

            Player myPlayer;
            SpriteItem itemOneSprite;

            @Override
            public void execute(){

                integrityCheck();

                if(mustHop01 || mustHop02 || mustHop03){
                    print("Current World: " + Worlds.getCurrent());
                    print("Old World: " + oldWorld);
                    print("Waiting to Hop");

                    if(mustHop01){
                        print("Boolean flag 1");
                    }
                    if(mustHop02){
                        print("Boolean flag 2");
                    }
                    if(mustHop03){
                        print("Boolean flag 3");
                    }

                    return;
                }

                if(houseArea.contains(myPlayer) && myPlayer.getPosition().getPlane() == 0){
                    if(farmerNPC != null) {
                        if(Inventory.getEmptySlots() == 1) {
                            if (houseArea.contains(farmerNPC)) {
                                try {
                                    if (farmerPos.equals(farmerNPC.getPosition()) && fastPickpocket) {
                                        standingStill = true;
                                    } else {
                                        standingStill = false;
                                    }
                                }catch (NullPointerException npe){}
                                if(standingStill && fastPickpocket) {
                                    if (!Menu.contains("Pickpocket") ) {
                                        try {
                                            if(farmerNPC.getInteractionPoint().hover()){
                                                Execution.delay(100,200);
                                            }

                                        } catch (NullPointerException npe) {
                                            npe.printStackTrace();
                                        }
                                    } else {
                                        if(Menu.contains("Pickpocket")){
                                            Mouse.click(Mouse.Button.LEFT);
                                            Execution.delay(127, minorVariantInt * 100);
                                        }
                                    }
                                }
                                else{
                                    if(farmerNPC.interact("Pickpocket")){
                                        Execution.delay(127, minorVariantInt * 100);
                                    }
                                    if(fastPickpocket) {
                                        try {
                                            farmerPos = farmerNPC.getPosition();
                                        }
                                        catch (NullPointerException npe) {
                                            npe.printStackTrace();
                                        }
                                    }
                                }
                            }
                            else{
                                if(playerNumbersTimer.isRunning()){
                                    farmerNPC = null;
                                    print("Farmer Outside + Players nearby: Hopping to different world.");
                                    cameraFix = 0;
                                    WorldHop.hopToRandom(true);
                                    Execution.delay(2700, 4300);
                                    return;
                                }
                                else {
                                    if (houseArea.contains(myPlayer)) {
                                        BresenhamPath jog = BresenhamPath.buildTo(waitArea.getCenter());
                                        if (!waitArea.contains(myPlayer)) {
                                            jog.step();
                                            Execution.delay(707,909);
                                        }
                                    }
                                }
                            }
                        }
                        else{
                            if(dropSeeds){
                                Keyboard.pressKey(16);
                                Execution.delay(100,200);
                                try {
                                    itemOneSprite.interact("Drop");
                                }catch (NullPointerException npe){
                                    System.out.println("Seed Error:2");
                                    npe.printStackTrace();
                                }
                                Execution.delay(375,450);
                                Keyboard.releaseKey(16);
                            }
                            else{
                                if(seedBoxSprite != null){
                                    seedBoxSprite.interact("Fill");
                                    Execution.delay(475,550);
                                }
                            }

                        }
                    }
                }
                else{
                    if(houseUpArea.contains(myPlayer) && myPlayer.getPosition().getPlane() == 1){
                        farmerNPC = null;
                        Coordinate goDown = new Coordinate(1783,3672,1);
                        try{
                            goDown.click();
                            Execution.delay(2000);
                        }catch (NullPointerException npe){}

                    }
                    else{
                        print("In Unknown Location");
                        Execution.delay(5000, 7000);
                        if(houseArea.contains(myPlayer)){
                            RuneScape.logout();
                        }

                    }

                }
                if(!RuneScape.isLoggedIn()){
                    if(logoutTimer.isRunning() && logoutTimer.getRemainingTime() < 10000) {
                        print("Not logged in: Stopping Bot");
                        print("Report:");
                        print(chatLog.toString());
                        print("Extra:");
                        print(Chatbox.getMessages(Chatbox.Message.Type.PUBLIC_CHAT).toString());
                        Environment.getBot().stop("Disconnected");
                    }
                }
            }

            boolean extendSession = false;
            boolean mustHop01 = false;
            boolean mustHop02 = false;
            boolean mustHop03 = false;
            int maxFlag = 0;
            int oldWorld = Worlds.getCurrent();
            Timer worldTimer = new Timer(100);
            Timer maxTimer = new Timer(100);
            Timer menuStallCheck = new Timer(100);
            Timer playerNumbersTimer = new Timer(100);
            Timer logoutTimer = new Timer(100);
            Timer chatTimer = new Timer(100);
            Timer breakTimer = new Timer(100);
            Timer refreshFarmer = new Timer(100);
            ArrayList<String> chatLog = new ArrayList<>();

            int oldMessages = 0;
            public void integrityCheck(){
                setVariance();
                myPlayer = Players.getLocal();
                seedBoxSprite = Inventory.newQuery().names("Seed box").results().first();
                if(farmerNPC == null || (farmerNPC != null && !houseArea.contains(farmerNPC))){
                    farmerNPC = Npcs.newQuery().within(houseArea).names("Master Farmer").results().first();
                }
                if ((Camera.getYaw() < 255 || Camera.getYaw() > 350) && cameraFix < 2) {
                    Camera.turnTo(235 - (int) ((Math.random() * 7)));
                    Execution.delay(505, 707);
                    cameraFix++;
                    return;
                }

                if(Camera.getPitch() < 9.0  && cameraFix < 2){
                    Camera.turnTo(1.0);
                    Execution.delay(505, 707);
                    cameraFix++;
                    return;
                }

                if(Equipment.contains("Ancient blessing")){
                    fastPickpocket = true;
                }
                if(Equipment.contains("Amulet of glory(6)") || Equipment.contains("Xeric's talisman") || Equipment.contains("Amulet of glory")){
                    extendSession = true;
                }
                if(Inventory.getEmptySlots() == 0){
                    try {
                        if(Inventory.getItemIn(0).getDefinition().getName().equals("Coin pouch")){
                            Environment.getBot().stop("Pouch");
                        }
                        itemOneSprite = Inventory.getItemIn(0);
                        if(Arrays.asList(specialSeedsArr).contains(itemOneSprite.getDefinition().getName())){
                            dropSeeds = false;
                        }
                        else{
                            dropSeeds = true;
                        }
                    }catch (NullPointerException npe){
                        System.out.println("Seed Error:1");
                        npe.printStackTrace();
                        itemOneSprite = null;
                    }

                }
                else{
                    dropSeeds = false;
                    itemOneSprite = null;
                }

                if(!menuStallCheck.isRunning()){
                    if(Menu.isOpen() || Inventory.getSelectedItem() != null){
                        menuStallCheck = new Timer(8000,12000);
                        menuStallCheck.start();
                    }
                }
                else{
                    if(Menu.isOpen() || Inventory.getSelectedItem() != null){
                        if(menuStallCheck.getRemainingTime() <= 5000){
                            ControlPanelTab.INVENTORY.getComponent().click();
                            Execution.delay(2000,3000);
                        }
                    }
                    else{
                        menuStallCheck.stop();
                    }
                }

                if(!maxTimer.isRunning()){
                    if(maxFlag > 0){
                        if(extendSession){
                            if (maxFlag > 1){
                                print("Out of Time");
                                RuneScape.logout();
                                Execution.delay(1000,2200);
                            }
                            else {
                                maxTimer = new Timer(18000000, 20800000);
                                maxTimer.start();
                                maxFlag = 2;
                                print("Extending Session");
                                while (oldWorld == Worlds.getCurrent() || RuneScape.isLoggedIn()) {
                                    WorldHop.hopToRandom(true);
                                    Execution.delay(808, 1101);
                                    farmerNPC = null;
                                    cameraFix = 0;
                                }
                                Execution.delay(1808, 2901);
                                oldWorld = Worlds.getCurrent();
                            }
                        }
                        else{
                            print("Out of Time");
                            RuneScape.logout();
                            Execution.delay(1000,2200);
                        }
                    }
                    else{
                        maxTimer = new Timer(18000000, 20800000);
                        maxTimer.start();
                        maxFlag = 1;
                    }
                }


                if(!playerNumbersTimer.isRunning()){
                    if(Players.newQuery().within(wideArea).results().size() >= 2){
                        print("Starting Paranoia Timer");
                        playerNumbersTimer = new Timer(120000, 180000);
                        playerNumbersTimer.start();
                    }
                }
                else{
                    if(Players.newQuery().within(wideArea).results().size() >= 2) {
                        if (playerNumbersTimer.getRemainingTime() <= 35000) {
                            setChatLog();
                            mustHop01 = true;
                            farmerNPC = null;
                            print("Paranoia-People: Hopping to different world.");
                            cameraFix = 0;
                            WorldHop.hopToRandom(true);
                            Execution.delay(2700, 4300);
                        }
                    }
                    else{
                        mustHop01 = false;
                        playerNumbersTimer.stop();
                        print("Ending Paranoia Timer");
                    }
                }
                if(!logoutTimer.isRunning()){
                    if(!RuneScape.isLoggedIn()){
                        logoutTimer = new Timer(22000, 24000);
                        logoutTimer.start();
                        mustHop01 = false;
                        mustHop02 = false;
                        mustHop03 = false;

                    }
                }
                else{
                    if(RuneScape.isLoggedIn()){
                        logoutTimer.stop();
                    }
                }
                if(!chatTimer.isRunning()){
                    try {
                        if (false && Chatbox.getMessages(Chatbox.Message.Type.PUBLIC_CHAT).size() > oldMessages) {
                            chatTimer = new Timer(62000, 74000);
                            chatTimer.start();
                        }
                    }catch (Exception e){
                        //Ignore
                    }
                }
                else{
                    if(false && Chatbox.getMessages(Chatbox.Message.Type.PUBLIC_CHAT).size() > oldMessages + 2){
                        mustHop02 = true;
                        if(Worlds.getCurrent() == oldWorld) {
                            setChatLog();
                            farmerNPC = null;
                            print("Public Messages");
                            print("---");
                            print(Chatbox.getMessages(Chatbox.Message.Type.PUBLIC_CHAT).toString());
                            print("---");
                            print("Paranoia-Chat: Hopping to different world.");
                            cameraFix = 0;
                            WorldHop.hopToRandom(true);
                            Execution.delay(2700, 4300);
                        }
                    }
                    else{
                        if(chatTimer.getRemainingTime() < 35000){
                            try {
                                //oldMessages = Chatbox.getMessages(Chatbox.Message.Type.PUBLIC_CHAT).size();
                            }catch (Exception e){
                                //Ignore
                            }
                        }
                        mustHop02 = false;
                    }

                    if(mustHop02 && Worlds.getCurrent() != oldWorld) {
                        mustHop02 = false;
                        oldWorld = Worlds.getCurrent();
                        oldMessages = Chatbox.getMessages(Chatbox.Message.Type.PUBLIC_CHAT).size();
                    }
                }

                if(!worldTimer.isRunning()){
                    if(oldWorld != Worlds.getCurrent() || mustHop01 || mustHop02 || mustHop03){
                        worldTimer = new Timer(43000, 50000);
                        worldTimer.start();
                    }
                }
                else{
                    if(worldTimer.getRemainingTime() < 20000){
                        oldWorld = Worlds.getCurrent();
                        mustHop01 = false;
                        mustHop02 = false;
                        mustHop03 = false;

                        if(maxFlag < 2){
                            maxTimer = new Timer(18000000, 20800000);
                            maxTimer.start();
                        }

                    }
                }

                if(!breakTimer.isRunning()){
                    breakTimer = new Timer(900000 * minorVariantInt, 6000000 * minorVariantInt);
                    breakTimer.start();
                }
                else{
                    if(breakTimer.getRemainingTime() < 30000){
                        breakTimer.stop();
                        print("Break Time");
                        Execution.delay(20000 * minorVariantInt, 180000);
                    }
                }
                if(!refreshFarmer.isRunning()){
                    farmerNPC = null;
                    refreshFarmer = new Timer(1000 * 60 * 4);
                    refreshFarmer.start();
                }

                if(Players.newQuery().within(houseArea).results().size() >= 3){
                    setChatLog();
                    print(">= 3 People in House");
                    mustHop03 = true;
                    if(Worlds.getCurrent() == oldWorld) {
                        farmerNPC = null;
                        print("Paranoia-Too Many People in House: Hopping to different world.");
                        cameraFix = 0;
                        WorldHop.hopToRandom(true);
                        Execution.delay(2700, 4300);
                    }
                }
                else {
                    mustHop03 = false;
                }

                if(dangerArea.contains(myPlayer)){
                    print("In danger area");
                    RuneScape.logout();
                    Execution.delay(1000,2200);
                }

            }

            Timer varianceTimer = new Timer(1000 * 60 * 12, 1000 * 60 * 20);
            int minorVariantInt = 0;
            int majorVariantInt = 0;

            public void setVariance(){
                if(!varianceTimer.isRunning()){
                    varianceTimer = new Timer(1000 * 60 * 12, 1000 * 60 * 20);
                    varianceTimer.start();
                    minorVariantInt = Random.nextInt(2,4);
                    majorVariantInt = Random.nextInt(100, 300);
                }
            }

            Timer chatLogTimer = new Timer(100);
            public void setChatLog(){
                if(maxFlag == 1){
                    maxTimer = new Timer(18000000, 20800000);
                    maxTimer.start();
                }
                if(!chatLogTimer.isRunning()){
                    for (int i = 0; i < 3; i++) {
                        try{
                            if(Chatbox.getMessages(Chatbox.Message.Type.PUBLIC_CHAT).size() >= 2) {
                                chatLog.add(Chatbox.getMessages(Chatbox.Message.Type.PUBLIC_CHAT).get(Chatbox.getMessages(Chatbox.Message.Type.PUBLIC_CHAT).size() - 1 - i).toString());
                            }
                        }catch (Exception e){

                        }

                    }
                    chatLogTimer = new Timer(10000,15000);
                    chatLogTimer.start();
                }
            }

            public void print(String x) {
                System.out.println(x);
            }
        };
    }

    @Override
    public ObjectProperty<? extends Node> botInterfaceProperty() {
        if(botInterfaceProperty == null){
            FXMLLoader loader = new FXMLLoader();
            controller = new MasterController(this);
            loader.setController(controller);
            try{
                Node node = loader.load(Resources.getAsStream("thief/master/MasterUI.fxml"));
                botInterfaceProperty = new SimpleObjectProperty<>(node);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return botInterfaceProperty;
    }
}
